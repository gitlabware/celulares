<?php
App::uses('AppModel', 'Model');
/**
 * Marca Model
 *
 */
class Marca extends AppModel {

}
